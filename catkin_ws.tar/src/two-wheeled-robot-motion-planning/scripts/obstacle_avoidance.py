#! /usr/bin/env python

import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

pub = None

def clbk_laser(msg):
    regions = {
        'right':  min(min(msg.ranges[0:143]), 10),
        'fright': min(min(msg.ranges[100:288]), 10),
        'front':  min(min(msg.ranges[250:470]), 10),
        'fleft':  min(min(msg.ranges[432:600]), 10),
        'left':   min(min(msg.ranges[580:719]), 10),
    }

    rospy.loginfo(f"Laser readings: {regions}")
    take_action(regions)

def take_action(regions):
    msg = Twist()
    state_description = ''
    
    d = 1.5  # Safe distance from obstacle

    # Emergency reverse
    if regions['front'] < 0.6 and regions['fleft'] < 0.6 and regions['fright'] < 0.6:
        state_description = '🔁 Too close! Reversing fast...'
        msg.linear.x = -0.4
        msg.angular.z = 0.7

    elif regions['front'] > d and regions['fleft'] > d and regions['fright'] > d:
        state_description = '✅ Path clear - zooming forward'
        msg.linear.x = 1.5
        msg.angular.z = 0.0

    elif regions['front'] < d and regions['fleft'] > d and regions['fright'] > d:
        state_description = '🟥 Obstacle ahead - turning left'
        msg.linear.x = 0.0
        msg.angular.z = 0.9

    elif regions['fright'] < d and regions['front'] > d:
        state_description = '↪ Obstacle front-right - adjust left'
        msg.linear.x = 0.7
        msg.angular.z = 0.7

    elif regions['fleft'] < d and regions['front'] > d:
        state_description = '↩ Obstacle front-left - adjust right'
        msg.linear.x = 0.7
        msg.angular.z = -0.7

    elif regions['front'] < d and regions['fright'] < d:
        state_description = '🟧 Front + right blocked - sharp left'
        msg.linear.x = 0.0
        msg.angular.z = 0.9

    elif regions['front'] < d and regions['fleft'] < d:
        state_description = '🟨 Front + left blocked - sharp right'
        msg.linear.x = 0.0
        msg.angular.z = -0.9

    elif regions['front'] < d and regions['fright'] < d and regions['fleft'] < d:
        state_description = '🛑 Surrounded - reversing quick!'
        msg.linear.x = -0.4
        msg.angular.z = 0.8

    elif regions['front'] > d and regions['fleft'] < d and regions['fright'] < d:
        state_description = '⚠️ Corridor - careful forward'
        msg.linear.x = 0.7
        msg.angular.z = 0.0

    else:
        state_description = '❓ Unknown - stopping'
        msg.linear.x = 0.0
        msg.angular.z = 0.0

    rospy.loginfo(state_description)
    pub.publish(msg)

def main():
    global pub

    rospy.init_node('obstacle_avoidance')

    pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
    sub = rospy.Subscriber('/m2wr/laser/scan', LaserScan, clbk_laser)

    rospy.spin()

if __name__ == '__main__':
    main()
